<?php
session_start();
require("function.php");
if(! isset($_POST["act"])) {
    exit(0);
}

$act =$_POST["act"];
switch($act) {
	case "purchase":
        $quantity1=$_POST['quantity1'];
        $quantity2=$_POST['quantity2'];
        $quantity3=$_POST['quantity3'];
        if ($quantity1) { //if title is not empty
            if (purchase($quantity1,$quantity2,$quantity3)) {
                header("Location: main_store.php"); 
            } else {
                echo( "insert failed.<br>");
            }
        } else {
            echo "Quantity cannot be empty!";
        }
        break;    
	case "askForProduct":
        $quantity1=$_POST['quantity1'];
        $quantity2=$_POST['quantity2'];
        $quantity3=$_POST['quantity3'];
        if ($quantity1) { //if title is not empty
            if (askProduct($quantity1,$quantity2,$quantity3)) {
                header("Location: branch.php"); 
            } else {
                echo( "insert failed.<br>");
            }
        } else {
            echo "Quantity cannot be empty!";
        }
    default:
}
?>