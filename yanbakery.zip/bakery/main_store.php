<?php 
require("function.php");
session_start();
$result=mainStore();
//$result2=mainStock();
$_SESSION['uID'] = "1";
/*require("User.php");
$uID=$_SESSION['uID'];*/
?>
<h1>Main Store</h1>

<h2>Main_Store</h2>
<table border="2">
<h4>Funds:</h4>
　  <tr>
    <td>Branch:</td>
	<td>Product name:</td>
	<td>Stock :</td>
	<td>Status :</td>
  　</tr>
<?php
if ($result) {
	while (	$rs=mysqli_fetch_assoc($result)) {
        echo "<h4>" . $rs['funds'] . "</h4>";
		echo "<tr><td>" . $rs['branch_number'] . "</td>";
		echo "<td>" . $rs['p_name'] . "</td>";
		echo "<td>" . $rs['stock_quantity'] . "</td>";
		echo "<td>" . $rs['p_status'] . "</td></tr>";
		//echo "<td>" . $rs['stock_quantity'] . "</td>";
		//echo "<td>" . $rs['purchase_status'] . "</td>";
		//echo "<td>" . $rs['stock_quantity'] . "</td>";
		//echo "<td><a href='watchWorkList.php?loginid={$rs['loginid']}'>watch</a></td>";
		//echo "<td><a href='QandAList.php?loginid={$rs['loginid']}'>Q&A</a></td>";
		//echo "<td>" . $rs['purchase_status'] . "</td>";
	}
	/*?loginid={$rs['loginid']}*/
} else {
	echo "<tr><td>No data found!<td></tr>";
}
?>
</table>

<input type="button" value="Purchase" onclick="location.href='purchase_form.php'" />
<input type="button" value="Branch" onclick="location.href='branch.php'" />


