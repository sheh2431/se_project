<?php
require("dbconnect.php");


function mainStore() {
	global $conn;
	$sql1 = "select DISTINCT main_store.funds,main_store.branch_number,product.p_name,product.purchase_price,product.stock_quantity,product.p_status from main_store,product order by main_store.funds";
	//$sql1 ="select DISTINCT branch_number,funds from main_store;"; 
	//$sql2 ="select * from product;"; 
	//$sql2 ="select DISTINCT funds from main_store";
	//$sql3 = $sql1 + $sql2;
	return (mysqli_query($conn,$sql1));
}

function branchStore() {
	global $conn;
	$sql1 = "select DISTINCT product.p_name,branch_stock.stock_limit,product.ship_price,branch.revenue,branch_stock.stock_quantity from branch,branch_stock,product";
	return (mysqli_query($conn,$sql1));
}

function purchase($quantity1,$quantity2,$quantity3) {
	global $conn;
	$sql1 = "update product set stock_quantity = stock_quantity + '$quantity1' where pid = '1'";
	$sql2 = "update product set stock_quantity = stock_quantity + '$quantity2' where pid = '2'";
	$sql3 = "update product set stock_quantity = stock_quantity + '$quantity3' where pid = '3'";	
	$sql4 = "update main_store,product set main_store.funds = main_store.funds - '$quantity1'* product.purchase_price where pid = '1'";
	$sql5 = "update main_store,product set main_store.funds = main_store.funds - '$quantity2'* product.purchase_price where pid = '2'";
    $sql6 = "update main_store,product set main_store.funds = main_store.funds - '$quantity3'* product.purchase_price where pid = '3'";
	return (mysqli_query($conn,$sql1) && mysqli_query($conn,$sql2) && mysqli_query($conn,$sql3)&& mysqli_query($conn,$sql4)&& mysqli_query($conn,$sql5)&& mysqli_query($conn,$sql6));
}

function askProduct($quantity1,$quantity2,$quantity3) {
	global $conn;
	$sql1 = "update branch_stock set stock_quantity = stock_quantity + '$quantity1' where pid = '1'";
	$sql2 = "update branch_stock set stock_quantity = stock_quantity + '$quantity2' where pid = '2'";
	$sql3 = "update branch_stock set stock_quantity = stock_quantity + '$quantity3' where pid = '3'";	
	$sql4 = "update product set stock_quantity = stock_quantity - '$quantity1' where pid = '1'";
	$sql5 = "update product set stock_quantity = stock_quantity - '$quantity2' where pid = '2'";
    $sql6 = "update product set stock_quantity = stock_quantity - '$quantity3' where pid = '3'";
	return (mysqli_query($conn,$sql1) && mysqli_query($conn,$sql2) && mysqli_query($conn,$sql3)&& mysqli_query($conn,$sql4)&& mysqli_query($conn,$sql5)&& mysqli_query($conn,$sql6));
}

?>