<?php 
require("function.php");
session_start();
$result=branchStore();
$_SESSION['uID'] = "1";
?>
<h1>Branch</h1>

<h2>Branch_Store 1</h2>
<h3>Stock</h3>
<table border="2">
　  <tr>
    <td>Product name:</td>
    <td>Limit Stock:</td>
	<td>Price:</td>
    <td>Stock:</td>
	<td>Revenue:</td>
  　</tr>
<?php
if ($result) {
	while (	$rs=mysqli_fetch_assoc($result)) {
		echo "<tr><td>" . $rs['p_name'] . "</td>";
        echo "<td>" . $rs['stock_limit'] . "</td>";
		echo "<td>" . $rs['ship_price'] . "</td>";
		echo "<td>" . $rs['stock_quantity'] . "</td>";
		echo "<td>" . $rs['revenue'] . "</td></tr>";
		//echo "<td><a href='watchWorkList.php?loginid={$rs['loginid']}'>watch</a></td>";
		//echo "<td><a href='QandAList.php?loginid={$rs['loginid']}'>Q&A</a></td>";
		//echo "<td>" . $rs['purchase_status'] . "</td>";
	}
	/*?loginid={$rs['loginid']}*/
} else {
	echo "<tr><td>No data found!<td></tr>";
}
?>
</table>

<br />
<input type="button" value="Ask For Product" onclick="location.href='AskProductForm.php'" />

<input type="button" value="Back To Main_store" onclick="location.href='main_store.php'" />