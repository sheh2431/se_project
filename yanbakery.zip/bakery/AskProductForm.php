<?php
session_start();
require("function.php");
$result1=mainStore();
$_SESSION['uID'] = "1";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
</head>
<body>
<h1>Purchase</h1>
<table border="2">
　  <tr>
    <td>Product name:</td>
	<td>Stock :</td>
  　</tr>
<?php
if ($result1) {
	while (	$rs=mysqli_fetch_assoc($result1)) {
        echo "<tr><td>" . $rs['p_name'] . "</td>";
		echo "<td>" . $rs['stock_quantity'] . "</td>";
	}
} else {
	echo "<tr><td>No data found!<td></tr>";
}
?>
</table>
<HR border = "2"> 
<form method="post" action="controller.php">
    <h2>Type what u need!</h2>
	<br />
	<input type="hidden" name="act" value="askForProduct">
      A quantity: <input name="quantity1" type="text" id="quantity1" /> <br>
	  B quantity: <input name="quantity2" type="text" id="quantity2" /> <br>
	  C quantity: <input name="quantity3" type="text" id="quantity3" /> <br>
    <input type="submit" name="Submit" value="送出" />
</form>
</body>
</html>